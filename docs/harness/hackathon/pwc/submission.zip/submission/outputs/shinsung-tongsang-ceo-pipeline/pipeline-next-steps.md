# CEO Consulting Pipeline Next Steps

## Pipeline

```text
spreadsheets
  -> trusted-ceo-agent (identity gate -> diagnose -> briefing -> eval)
  -> compliance-review / compliance-language
  -> documents
```

## Confirmed Inputs

- 기업명: `신성통상`
- 사업자등록번호: `104-81-01106`
- 내부 표준 CSV 폴더: 미제공. DART/ECOS/뉴스 기반 외부 진단 모드로 진행.
- 식별 게이트 결과: `C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\identity.json`
- 진단 패킷: `C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\diagnostic-packet.json`

## 1. Spreadsheets

고객 원본 Excel/CSV가 있으면 먼저 `spreadsheets` 플러그인으로 다음 표준 파일을 만든다.

```text
trial_balance.csv
ar_aging.csv
cost_allocation.csv
```

이미 `--data-dir` 로 표준 CSV 폴더를 넘겼다면 이 단계는 완료된 것으로 본다.

## 2. Trusted CEO Agent — 브리핑

이미 생성·채점됨: `C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\briefing.md` — 아래 프롬프트는 재생성용.

```text
기업명 신성통상, 사업자등록번호 104-81-01106 기준으로 identity.json과 diagnostic-packet.json을 근거로 CEO 브리핑을 작성해줘.
내부 CSV가 있으면 정합성 게이트와 신호 파생 결과를 우선하고, DART/ECOS/네이버 뉴스 신호를 보조 근거로 결합해줘.
각 리스크는 결론, 근거 수치, 확신도, 추가 확인 절차, 권고 조치 순서로 작성해줘.
검토용 산출물은 C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\briefing.md 로 저장해줘.
```

## 3. Compliance Review / Language

브리핑 확정 전 아래를 검수한다.

- PII: 대표자명, 계좌번호, 주민번호, 카드번호, 실명+연락처 조합이 불필요하게 노출되지 않는가
- Auditability: 어떤 수치가 어떤 파일/API/시점에서 왔는지 추적 가능한가
- Language: 투자 수익 보장, 원금 보장, 확실한 상승/하락, 매수/매도 지시형 표현이 없는가
- Boundary: CEO 경영 판단 보조 자료이며 투자자문/투자권유가 아님을 명시했는가

## 4. Documents

`documents` 플러그인으로 최종 Word 보고서를 만든다.

```text
C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\briefing.md 내용을 바탕으로 CEO/파트너 제출용 Word 보고서 C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\briefing.docx 를 생성해줘.
표지는 기업명, 분석 기준일, 데이터 출처 요약을 포함하고, 본문은 결론-핵심 리스크-근거-권고 조치-부록 순서로 구성해줘.
```

## Verification

```powershell
node src/test/briefing-eval.mjs --signals-file "C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\diagnostic-packet.json" "C:\Users\iamip\IdeaProjects\kubenetis\settlement\pwc\submission\outputs\shinsung-tongsang-ceo-pipeline\briefing.md"
```
